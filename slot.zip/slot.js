function se1(){
  var se1 = document.getElementById("se1");
  se1.load();
  se1.play();
}
function se2(){
  var se2 = document.getElementById("se2");
  se2.load();
  se2.play();
}
function se3(){
  var se3 = document.getElementById("se3");
  se3.load();
  se3.play();
}
function se4(){
  var se4 = document.getElementById("se4");
  se4.load();
  se4.play();
}
function start(){
  document.getElementById("display").style.display="none";
  document.js.slot1.value = "-";
  document.js.slot2.value = "-";
  document.js.slot3.value = "-";
  se3();
}
function random1(){
  document.js.slot1.value = Math.floor(Math.random()*9)+1;
}
function random2(){
  document.js.slot2.value = Math.floor(Math.random()*9)+1;
}
function random3(){
  document.js.slot3.value = Math.floor(Math.random()*9)+1;
}
function end(){
  var slot1 = document.js.slot1.value;
  var slot2 = document.js.slot2.value;
  var slot3 = document.js.slot3.value;
  if(slot1 == slot2 && slot2 == slot3){
    se4();
    alert("おめでとう！3つ数字がそろったのでSEが流れました！");
    se3();
  }else{
    se2();
  }
  document.getElementById("display").style.display="block";
}
function play(){
  start();
  setTimeout(function(){se1();random1();}, 200);
  setTimeout(function(){se1();random2();}, 400);
  setTimeout(function(){se1();random3();}, 600);
  setTimeout(function(){se2();end();}, 800);
}